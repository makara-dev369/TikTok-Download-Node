1. npm install
2. node allvideouser.js address: tiktok profile.
