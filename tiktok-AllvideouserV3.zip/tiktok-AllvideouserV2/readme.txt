1. npm install
2. node allvideouser.js address: tiktok profile.

Example:
node allvideouser.js https://www.tiktok.com/@kawaiiwaii8?is_from_webapp=1&sender_device=pc